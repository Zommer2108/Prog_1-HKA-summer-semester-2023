public class IntAppJin {
    public static void main(String[] args) {
        IntListJin list = new IntListJin();

        list.addLast(5);
        list.addLast(3);
        list.addLast(5);
        list.addLast(5);
        list.addLast(5);
        list.addLast(5);
        list.addLast(5);
        list.addLast(6);
        list.addLast(5);
        list.addLast(8);
        list.addLast(5);
        list.addLast(7);
        list.addLast(5);

        list.remove(5);



        System.out.println(list);
    }



}
